import React, { useEffect, useState } from "react";
// import TourCard from "../components/TourCard";
import TourCard from "../../components/TourCard";
import AddTourModal from "../../components/AddTourModal";
import styles from "../../styles/Tours.module.css";
import api from "../../auth/api";

const Tours = () => {
  const [tours, setTours] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [filters, setFilters] = useState({
    title: "",
    location: "",
    rating: "",
    sort: "",
    page: 1,
    limit: 10,
  });
  const [pagination, setPagination] = useState({
    currentPage: 1,
    totalPages: 1,
    totalResults: 0,
  });

  const fetchTours = async () => {
    try {
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.append(key, value);
      });

      const res = await api.get(`/tours?${params.toString()}`);
      setTours(res.data.data);
      setPagination({
        currentPage: res.data.page,
        totalPages: Math.ceil(res.data.totalResults / filters.limit),
        totalResults: res.data.totalResults,
      });
    } catch (error) {
      console.error("Error fetching tours", error);
    }
  };

  useEffect(() => {
    fetchTours();
  }, [filters]);

  const handleFilterChange = (e) => {
    const { name, value } = e.target;
    setFilters((prev) => ({
      ...prev,
      [name]: value,
      page: 1, // Reset to first page when filters change
    }));
  };

  const handlePageChange = (newPage) => {
    setFilters((prev) => ({
      ...prev,
      page: newPage,
    }));
  };

  return (
    <div className={styles.wrapper}>
      <h1 className={styles.title}>Travel Destinations</h1>

      <div className={styles.filters}>
        <input
          type="text"
          name="title"
          placeholder="Search by title"
          value={filters.title}
          onChange={handleFilterChange}
          className={styles.filterInput}
        />
        <input
          type="text"
          name="location"
          placeholder="Search by location"
          value={filters.location}
          onChange={handleFilterChange}
          className={styles.filterInput}
        />
        <input
          type="number"
          name="rating"
          placeholder="Minimum rating"
          value={filters.rating}
          onChange={handleFilterChange}
          className={styles.filterInput}
        />
        <select
          name="sort"
          value={filters.sort}
          onChange={handleFilterChange}
          className={styles.filterInput}
        >
          <option value="">Sort by...</option>
          <option value="price">Price: Low to High</option>
          <option value="-price">Price: High to Low</option>
          <option value="averageRating">Rating: Low to High</option>
          <option value="-averageRating">Rating: High to Low</option>
        </select>
      </div>

      <button onClick={() => setShowModal(true)} className={styles.addButton}>
        + Add New Tour
      </button>

      <ul className={styles.cards}>
        {tours.map((tour) => (
          <TourCard key={tour._id} tour={tour} />
        ))}
      </ul>

      <div className={styles.pagination}>
        <button
          onClick={() => handlePageChange(pagination.currentPage - 1)}
          disabled={pagination.currentPage === 1}
          className={styles.pageButton}
        >
          Previous
        </button>
        <span className={styles.pageInfo}>
          Page {pagination.currentPage} of {pagination.totalPages}
        </span>
        <button
          onClick={() => handlePageChange(pagination.currentPage + 1)}
          disabled={pagination.currentPage === pagination.totalPages}
          className={styles.pageButton}
        >
          Next
        </button>
      </div>

      {showModal && (
        <AddTourModal
          onClose={() => setShowModal(false)}
          onSuccess={fetchTours}
        />
      )}
    </div>
  );
};

export default Tours;
